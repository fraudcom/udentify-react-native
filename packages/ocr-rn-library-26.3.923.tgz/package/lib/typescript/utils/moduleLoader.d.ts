declare let OCRModule: any;
export { OCRModule };
//# sourceMappingURL=moduleLoader.d.ts.map