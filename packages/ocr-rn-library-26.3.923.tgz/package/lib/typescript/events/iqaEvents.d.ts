import type { IQAResult } from '../types/iqa.types';
export declare function addIQAResultListener(callback: (result: IQAResult) => void): () => void;
export declare function removeAllIQAResultListeners(): void;
//# sourceMappingURL=iqaEvents.d.ts.map