export interface DirectiveEvent {
    directive: string;
    timestamp: number;
}
export declare function addOCRDirectiveListener(callback: (event: DirectiveEvent) => void): () => void;
export declare function addHologramDirectiveListener(callback: (event: DirectiveEvent) => void): () => void;
export declare function removeAllDirectiveListeners(): void;
//# sourceMappingURL=directiveEvents.d.ts.map