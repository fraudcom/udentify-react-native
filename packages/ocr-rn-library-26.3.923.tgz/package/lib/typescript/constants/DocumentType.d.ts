export declare const DocumentType: {
    readonly ID_CARD: "ID_CARD";
    readonly PASSPORT: "PASSPORT";
    readonly DRIVER_LICENSE: "DRIVER_LICENSE";
};
export type DocumentTypeValue = typeof DocumentType[keyof typeof DocumentType];
//# sourceMappingURL=DocumentType.d.ts.map