export declare const IQAFeedback: {
    readonly SUCCESS: "success";
    readonly BLUR_DETECTED: "blurDetected";
    readonly GLARE_DETECTED: "glareDetected";
    readonly HOLOGRAM_GLARE: "hologramGlare";
    readonly CARD_NOT_DETECTED: "cardNotDetected";
    readonly CARD_CLASSIFICATION_MISMATCH: "cardClassificationMismatch";
    readonly CARD_NOT_INTACT: "cardNotIntact";
    readonly FACE_NOT_DETECTED: "faceNotDetected";
    readonly MULTIPLE_DOCUMENTS_DETECTED: "multipleDocumentsDetected";
    readonly CHIP_NOT_DETECTED: "chipNotDetected";
    readonly SIGNATURE_NOT_DETECTED: "signatureNotDetected";
    readonly MODEL_FAILED: "modelFailed";
    readonly HIDDEN_PHOTO_NOT_DETECTED: "hiddenPhotoNotDetected";
    readonly PHOTO_CHEAT_DETECTED: "photoCheatDetected";
    readonly OTHER: "other";
};
export type IQAFeedbackValue = typeof IQAFeedback[keyof typeof IQAFeedback];
//# sourceMappingURL=IQAFeedback.d.ts.map