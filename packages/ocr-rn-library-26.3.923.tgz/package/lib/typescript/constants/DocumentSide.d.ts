export declare const DocumentSide: {
    readonly FRONT: "FRONT";
    readonly BACK: "BACK";
    readonly BOTH: "BOTH";
};
export type DocumentSideValue = typeof DocumentSide[keyof typeof DocumentSide];
//# sourceMappingURL=DocumentSide.d.ts.map