import type { DocumentTypeValue } from '../constants/DocumentType';
import type { DocumentSideValue } from '../constants/DocumentSide';
export declare function startOCRScanning(serverURL: string, transactionID: string, documentType: DocumentTypeValue, documentSide: DocumentSideValue, country?: string): Promise<boolean>;
//# sourceMappingURL=scanning.d.ts.map