import type { DocumentTypeValue } from '../constants/DocumentType';
import type { OCRResponse, OCRAndDocumentLivenessResponse } from '../types/ocr.types';
export declare function performOCR(serverURL: string, transactionID: string, frontSideImage: string, backSideImage: string, documentType: DocumentTypeValue, country?: string): Promise<OCRResponse>;
export declare function performOCRAndDocumentLiveness(serverURL: string, transactionID: string, frontSideImage: string, backSideImage: string, documentType: DocumentTypeValue, country?: string): Promise<OCRAndDocumentLivenessResponse>;
//# sourceMappingURL=ocr.d.ts.map