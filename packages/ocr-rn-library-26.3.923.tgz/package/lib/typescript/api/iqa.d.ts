export interface PerformIQAResult {
    qualified: boolean;
    displayMessage?: string;
    rawMessage?: string;
    documentSide?: string;
    timestamp: number;
}
export declare function takePhoto(): Promise<string>;
export declare function performIQA(serverURL: string, transactionID: string, imageBase64: string, documentType: string, documentSide: string, country?: string): Promise<PerformIQAResult>;
//# sourceMappingURL=iqa.d.ts.map