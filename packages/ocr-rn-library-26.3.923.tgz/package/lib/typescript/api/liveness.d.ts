import type { DocumentLivenessResponse } from '../types/ui.types';
export declare function performDocumentLiveness(serverURL: string, transactionID: string, frontSideImage: string, backSideImage: string): Promise<DocumentLivenessResponse>;
//# sourceMappingURL=liveness.d.ts.map