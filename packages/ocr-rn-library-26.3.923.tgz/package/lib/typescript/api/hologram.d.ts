import type { HologramResponse } from '../types/hologram.types';
export declare function startHologramCamera(serverURL: string, transactionID: string): Promise<boolean>;
export declare function performHologramCheck(serverURL: string, transactionID: string, videoUrls: string[]): Promise<HologramResponse>;
//# sourceMappingURL=hologram.d.ts.map