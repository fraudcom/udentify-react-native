import type { OCRUIConfiguration } from '../types/ui.types';
export declare function configureUISettings(uiConfig: OCRUIConfiguration): Promise<boolean>;
//# sourceMappingURL=config.d.ts.map