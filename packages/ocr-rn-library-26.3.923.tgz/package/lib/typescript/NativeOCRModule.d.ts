import type { TurboModule } from 'react-native';
export interface UIConfig {
    backgroundColor?: string;
    borderColor?: string;
    cornerRadius?: number;
    borderWidth?: number;
    maskLayerColor?: string;
    buttonBackColor?: string;
    placeholderTemplate?: string;
    orientation?: string;
    detectionAccuracy?: number;
    blurCoefficient?: number;
    requestTimeout?: number;
    backButtonEnabled?: boolean;
    reviewScreenEnabled?: boolean;
    reviewBackgroundColor?: string;
    reviewBackgroundStyle?: Object;
    footerViewHidden?: boolean;
    manualCapture?: boolean;
    faceDetection?: boolean;
    isDocumentLivenessActive?: boolean;
    isIQAServiceEnabled?: boolean;
    iqaScreenStyle?: Object;
}
export interface Spec extends TurboModule {
    setRepeatConfig(config: Object | null): Promise<boolean>;
    configureUISettings(uiConfig: UIConfig): Promise<boolean>;
    startOCRScanning(serverURL: string, transactionID: string, documentType: string, documentSide: string, country: string): Promise<boolean>;
    performOCR(serverURL: string, transactionID: string, frontSideImage: string, backSideImage: string, documentType: string, country: string): Promise<object>;
    performDocumentLiveness(serverURL: string, transactionID: string, frontSideImage: string, backSideImage: string): Promise<object>;
    performOCRAndDocumentLiveness(serverURL: string, transactionID: string, frontSideImage: string, backSideImage: string, documentType: string, country: string): Promise<object>;
    startHologramCamera(serverURL: string, transactionID: string): Promise<boolean>;
    performHologramCheck(serverURL: string, transactionID: string, videoUrls: string[]): Promise<object>;
    performIQA(serverURL: string, transactionID: string, imageBase64: string, documentType: string, documentSide: string, country: string): Promise<object>;
    takePhoto(): Promise<string>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeOCRModule.d.ts.map