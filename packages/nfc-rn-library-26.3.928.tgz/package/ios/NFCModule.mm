//
//  NFCModule.mm
//  NFCLibrary
//
//  Created by React Native on 01/01/25.
//

#import <UIKit/UIKit.h>
#import "NFCModule.h"
#import "NFCManager.h"

#ifdef RCT_NEW_ARCH_ENABLED
#import "RNNFCLibrarySpec.h"
#endif

@interface NFCBundleHelper : NSObject
+ (void)publishLiveKYCBundle;
@end

// Import the Swift class properly
@interface NFCManagerSwift : NSObject
+ (instancetype)shared;
- (void)isNFCAvailableWithCompletion:(void (^)(BOOL available, NSError * _Nullable error))completion;
- (void)isNFCEnabledWithCompletion:(void (^)(BOOL enabled, NSError * _Nullable error))completion;
- (void)startNFCReadingWithCredentials:(NSDictionary *)credentials completion:(void (^)(NSDictionary * _Nullable result, NSError * _Nullable error))completion;
- (void)cancelNFCReadingWithCompletion:(void (^)(BOOL success, NSError * _Nullable error))completion;
- (void)getNFCLocationWithServerURL:(NSString *)serverURL completion:(void (^)(NSDictionary * _Nullable result, NSError * _Nullable error))completion;
@end

#ifdef RCT_NEW_ARCH_ENABLED
@interface NFCModule () <NativeNFCModuleSpec>
@end
#endif

@implementation NFCModule

RCT_EXPORT_MODULE(NFCModule)

// React creates a native module only when JS first calls it, which never happens
// in a video-call-only app - so the in-call NFC screen's bundle is published at
// app launch instead. +load is taken by RCT_EXPORT_MODULE, hence +initialize
// plus the launch notification.
+ (void)initialize
{
    if (self != [NFCModule class]) { return; }
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:^(NSNotification * _Nonnull note) {
        [NFCBundleHelper publishLiveKYCBundle];
    }];
}

+ (BOOL)requiresMainQueueSetup
{
    return NO;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(handleNFCProgress:)
                                                     name:@"NFCProgress"
                                                   object:nil];
    }
    return self;
}

- (NSArray<NSString *> *)supportedEvents
{
    return @[@"onNFCProgress"];
}

- (void)handleNFCProgress:(NSNotification *)notification
{
    NSNumber *progress = notification.userInfo[@"progress"];
    [self sendEventWithName:@"onNFCProgress" body:@{
        @"progress": progress ?: @0,
        @"timestamp": @([[NSDate date] timeIntervalSince1970] * 1000)
    }];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// MARK: - NFC Status Methods

RCT_EXPORT_METHOD(isNFCAvailable:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    [[NFCManagerSwift shared] isNFCAvailableWithCompletion:^(BOOL available, NSError * _Nullable error) {
        if (error) {
            reject(@"NFC_ERROR", error.localizedDescription, error);
        } else {
            resolve(@(available));
        }
    }];
}

RCT_EXPORT_METHOD(isNFCEnabled:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    [[NFCManagerSwift shared] isNFCEnabledWithCompletion:^(BOOL enabled, NSError * _Nullable error) {
        if (error) {
            reject(@"NFC_ERROR", error.localizedDescription, error);
        } else {
            resolve(@(enabled));
        }
    }];
}

// MARK: - NFC Reading Methods

RCT_EXPORT_METHOD(startNFCReading:(NSDictionary *)credentials
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    [[NFCManagerSwift shared] startNFCReadingWithCredentials:credentials completion:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        if (error) {
            reject(@"NFC_ERROR", error.localizedDescription, error);
        } else {
            resolve(result ?: @{});
        }
    }];
}

RCT_EXPORT_METHOD(cancelNFCReading:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    [[NFCManagerSwift shared] cancelNFCReadingWithCompletion:^(BOOL success, NSError * _Nullable error) {
        if (error) {
            reject(@"NFC_ERROR", error.localizedDescription, error);
        } else {
            resolve(@(success));
        }
    }];
}

// MARK: - NFC Location Methods

RCT_EXPORT_METHOD(getNFCLocation:(NSString *)serverURL
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
    [[NFCManagerSwift shared] getNFCLocationWithServerURL:serverURL completion:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        if (error) {
            reject(@"NFC_ERROR", error.localizedDescription, error);
        } else {
            resolve(result ?: @{});
        }
    }];
}

#ifdef RCT_NEW_ARCH_ENABLED
- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params
{
    return std::make_shared<facebook::react::NativeNFCModuleSpecJSI>(params);
}
#endif

@end
