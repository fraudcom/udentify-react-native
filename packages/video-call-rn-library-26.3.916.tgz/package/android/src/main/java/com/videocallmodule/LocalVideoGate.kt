package com.videocallmodule

import android.util.Log

/**
 * Android-only workaround: gates the local camera track's frame transmission
 * across app background/foreground.
 *
 * Why this exists: when the app is backgrounded the vendor SDK closes the
 * camera *device* (CameraX unbinds from the fragment's lifecycle) but never
 * disables the published LiveKit video track. The track stays live, so the
 * remote agent's decoder simply stops receiving frames and keeps painting the
 * last one - the agent is left staring at a frozen frame of the user's face
 * instead of a blank tile. Disabling the underlying MediaStreamTrack makes
 * WebRTC transmit black frames instead.
 *
 * This deliberately does NOT use `LocalParticipant.setCameraEnabled()`: that
 * one suspends and republishes the track, and is the path implicated in the
 * "camera never restarts after 10s in background" bug. `Track.setEnabled` is
 * synchronous, touches neither publication nor renegotiation, and the vendor
 * SDK never calls it itself - so nothing here races the SDK's own state
 * machine.
 *
 * Everything below is reflection against the vendor AAR's obfuscated
 * internals, so every step is null- and exception-tolerant: if a future SDK
 * build changes shape this degrades to today's behaviour (frozen frame) rather
 * than breaking the call. The LocalParticipant field is matched by TYPE rather
 * than name, because R8 renames the field on every SDK build while the type is
 * part of LiveKit's public API.
 *
 * Remove this once the SDK restores its own lifecycle video mute.
 */
internal object LocalVideoGate {
    private const val TAG = "LocalVideoGate"

    private const val LOCAL_PARTICIPANT = "io.livekit.android.room.participant.LocalParticipant"
    private const val TRACK_SOURCE = "io.livekit.android.room.track.Track\$Source"

    /** Returns true only if the track was actually found and toggled. */
    fun setEnabled(fragment: Any?, enabled: Boolean): Boolean {
        val frag = fragment ?: return false
        return try {
            val participant = findLocalParticipant(frag)
            if (participant == null) {
                Log.w(TAG, "no LocalParticipant on fragment; leaving video track alone")
                return false
            }
            val sourceClass = Class.forName(TRACK_SOURCE)
            val camera = sourceClass.getField("CAMERA").get(null)
            val publication = participant.javaClass
                .getMethod("getTrackPublication", sourceClass)
                .invoke(participant, camera) ?: return false
            val track = publication.javaClass
                .getMethod("getTrack")
                .invoke(publication) ?: return false
            track.javaClass
                .getMethod("setEnabled", Boolean::class.javaPrimitiveType)
                .invoke(track, enabled)
            Log.d(TAG, "local video track enabled=$enabled")
            true
        } catch (t: Throwable) {
            // A vendor-internal change must never break an in-progress call.
            Log.w(TAG, "could not toggle local video track (enabled=$enabled)", t)
            false
        }
    }

    // The vendor fragment holds its LocalParticipant in a public field whose
    // NAME is obfuscated, so match on the field's type. Walks superclasses too:
    // the field is declared on VideoCallFragment, not on the VCFragment
    // subclass the wrapper actually instantiates.
    private fun findLocalParticipant(fragment: Any): Any? {
        val target = Class.forName(LOCAL_PARTICIPANT)
        var klass: Class<*>? = fragment.javaClass
        while (klass != null && klass != Any::class.java) {
            for (field in klass.declaredFields) {
                if (target.isAssignableFrom(field.type)) {
                    field.isAccessible = true
                    return field.get(fragment)
                }
            }
            klass = klass.superclass
        }
        return null
    }
}
