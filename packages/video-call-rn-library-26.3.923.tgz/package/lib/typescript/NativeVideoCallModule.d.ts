import type { VideoCallCredentials, VideoCallResult, VideoCallStatus, VideoCallPermissionStatus, VideoCallCallbacks, VideoCallEventHandlers } from './VideoCallModels';
import type { VideoCallLocalizedStrings } from './NativeVideoCallModuleSpec';
export type { VideoCallCredentials as VideoCallCredentials_TurboModule, VideoCallResult as VideoCallResult_TurboModule, VideoCallLocalizedStrings, } from './NativeVideoCallModuleSpec';
/**
 * Subscribes to the native VideoCall_on* events for the lifetime of the
 * caller (typically one <VideoCallView> mount). Unlike
 * NativeVideoCallModule.setCallbacks() (a single global singleton
 * subscription, kept below for backward compatibility), this creates an
 */
export declare function subscribeToVideoCallEvents(handlers: VideoCallEventHandlers): {
    remove: () => void;
};
/**
 * Native Video Call Module - React Native bridge to native implementations
 * Provides the same functionality as Flutter VideoCallFlutter class
 */
export declare class NativeVideoCallModule {
    private static eventEmitter;
    private static callbacks;
    /**
     * Initialize event emitter safely
     */
    private static getEventEmitter;
    /**
     * Initialize event listeners for callbacks
     */
    private static initializeEventListeners;
    /**
     * Set callbacks for video call events
     */
    static setCallbacks(callbacks: VideoCallCallbacks): void;
    /**
     * Clear all event listeners
     */
    static clearEventListeners(): void;
    /**
     * Check current permissions status
     */
    static checkPermissions(): Promise<VideoCallPermissionStatus>;
    /**
     * Request necessary permissions for video call functionality
     */
    static requestPermissions(): Promise<string>;
    /**
     * Start video call with given credentials
     */
    static startVideoCall(credentials: VideoCallCredentials): Promise<VideoCallResult>;
    /**
     * End the ongoing video call, cancelling the transaction on the server so
     * the agent's session ends too.
     * `success` says whether there was a call to end. It stays `true` when the
     * server-side cancellation fails, with `error` describing it — worth logging,
     */
    static endVideoCall(): Promise<VideoCallResult>;
    /**
     * Get current video call status
     */
    static getVideoCallStatus(): Promise<VideoCallStatus>;
    /**
     * Resolves the SDK's own localized End Call button labels for the device's
     * current language. Falls back to English if the module isn't available or
     * the native call fails.
     */
    static getLocalizedStrings(): Promise<VideoCallLocalizedStrings>;
    /**
     * @deprecated Use setMicrophoneEnabled(). iOS-only, and it bypasses the
     * operator notification.
     */
    static toggleMicrophone(): Promise<boolean>;
    /**
     * Turn the microphone on or off. Resolves whether the request was accepted,
     * not whether it has taken effect - listen for onMicrophoneStateChanged.
     */
    static setMicrophoneEnabled(enabled: boolean): Promise<boolean>;
    /**
     * One-shot read of the live microphone state.
     */
    static isMicrophoneEnabled(): Promise<boolean>;
    /**
     * Dismiss video call UI
     */
    static dismissVideoCall(): Promise<void>;
    /**
     * Cancel an in-progress video call transaction on the server.
     * Requires an active/presented video call session.
     */
    static cancelVideoCall(): Promise<VideoCallResult>;
}
export default NativeVideoCallModule;
//# sourceMappingURL=NativeVideoCallModule.d.ts.map