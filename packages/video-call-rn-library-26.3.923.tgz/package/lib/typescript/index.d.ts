export * from './VideoCallModels';
export { NativeVideoCallModule, subscribeToVideoCallEvents } from './NativeVideoCallModule';
export { VideoCallView } from './VideoCallView';
export type { VideoCallViewProps } from './VideoCallView';
import type { VideoCallCredentials, VideoCallResult, VideoCallStatus, VideoCallPermissionStatus, VideoCallCallbacks } from './VideoCallModels';
import type { VideoCallLocalizedStrings } from './NativeVideoCallModule';
export type { VideoCallLocalizedStrings } from './NativeVideoCallModule';
/**
 * VideoCall - Main class for video call functionality
 * Equivalent to Flutter's VideoCallFlutter class
 * This class provides a simple interface for video calling using Udentify's SDK.
 * All methods are static and mirror the Flutter implementation.
 */
export declare class VideoCall {
    /**
     * Check current permissions status
     * @returns Promise<VideoCallPermissionStatus> Current permission status
     */
    static checkPermissions(): Promise<VideoCallPermissionStatus>;
    /**
     * Request necessary permissions for video call functionality
     * @returns Promise<string> Result of permission request ('granted' | 'denied' | 'error')
     */
    static requestPermissions(): Promise<string>;
    /**
     * @deprecated The call screen is no longer presented imperatively. Render
     * `<VideoCallView credentials={...} />` instead. This resolves immediately
     * with `{success: false, error: {...}}` and never starts a call; kept only
     * so existing call sites don't crash while migrating.
     */
    static startVideoCall(credentials: VideoCallCredentials): Promise<VideoCallResult>;
    /**
     * End ongoing video call
     * @returns Promise<VideoCallResult> Result of the end operation
     */
    static endVideoCall(): Promise<VideoCallResult>;
    /**
     * Get current video call status
     * @returns Promise<VideoCallStatus> Current status of the video call
     */
    static getVideoCallStatus(): Promise<VideoCallStatus>;
    /**
     * Resolves the SDK's own localized End Call button labels for the device's
     * current language ("End Call"/"Aramayı Sonlandır" and their in-progress
     * variants today), so an app-rendered End Call button stays consistent with
     * the rest of the SDK's localization instead of hardcoding the text.
     */
    static getLocalizedStrings(): Promise<VideoCallLocalizedStrings>;
    /**
     * @deprecated Use setMicrophoneEnabled(true/false) instead. iOS-only
     * (Android rejects with `ERR_NOT_SUPPORTED`), it does not notify the
     * operator console, and its result is relative to a state the SDK can change
     * on its own, so the next toggle can flip the wrong way round.
     * @returns Current microphone state after the toggle (true = on)
     */
    static toggleMicrophone(): Promise<boolean>;
    /**
     * Turn the microphone on or off explicitly. The operator console is told
     * too, so its mute indicator stays in sync with an app-driven change.
     * Acceptance is not completion - the microphone changes asynchronously, and
     * `onMicrophoneStateChanged` reports the real outcome.
     * @param enabled true = live, false = muted
     * @returns Whether the request was accepted (false = no active call)
     */
    static setMicrophoneEnabled(enabled: boolean): Promise<boolean>;
    /**
     * Read the live microphone state once (false when no call is active). For
     * UI, prefer `<VideoCallView onMicrophoneStateChanged>`: the SDK also mutes
     * and unmutes on its own - app backgrounded, audio focus lost, a real phone
     * call answered - so a value read here goes stale without warning.
     */
    static isMicrophoneEnabled(): Promise<boolean>;
    /**
     * @deprecated Alias for endVideoCall(). Unmount `<VideoCallView>` from JS
     * instead of calling this to "dismiss" the call UI.
     */
    static dismissVideoCall(): Promise<void>;
    /**
     * Cancel an in-progress video call transaction on the server.
     * Requires an active/presented video call session.
     * @returns Promise<VideoCallResult> Result of the cancel operation
     */
    static cancelVideoCall(): Promise<VideoCallResult>;
    /**
     * @deprecated Global singleton subscription - prefer `<VideoCallView>`'s own
     * event props (or `subscribeToVideoCallEvents()` for a per-mount
     * subscription), which don't leak across mount/unmount cycles the way this
     * single shared listener set can.
     * @param callbacks VideoCallCallbacks object with event handlers
     */
    static setCallbacks(callbacks: VideoCallCallbacks): void;
    /**
     * Clear all event listeners
     */
    static clearEventListeners(): void;
    /**
     * @deprecated See setCallbacks().
     * @param callback Function to handle status changes
     */
    static setOnStatusChanged(callback: (status: VideoCallStatus) => void): void;
    /**
     * @deprecated See setCallbacks().
     * @param callback Function to handle errors
     */
    static setOnError(callback: (error: any) => void): void;
}
export default VideoCall;
//# sourceMappingURL=index.d.ts.map