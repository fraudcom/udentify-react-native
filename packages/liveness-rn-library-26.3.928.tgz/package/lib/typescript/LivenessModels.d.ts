/**
 * Face Recognition & Liveness models for the liveness-rn-library
 * Based on the Flutter implementation models
 */
export declare enum FaceRecognitionMethod {
    REGISTER = "register",
    AUTHENTICATION = "authentication",
    PHOTO_UPLOAD = "photoUpload",
    SELFIE = "selfie"
}
export interface FaceRecognizerCredentials {
    serverURL: string;
    transactionID: string;
    userID: string;
    autoTake?: boolean;
    errorDelay?: number;
    successDelay?: number;
    runInBackground?: boolean;
    blinkDetectionEnabled?: boolean;
    requestTimeout?: number;
    eyesOpenThreshold?: number;
    maskConfidence?: number;
    /**
     * Opacity of the active-liveness gesture backdrop, `0`–`1`. **Android only.**
     * The SDK draws a full-screen image (`gesture_presentation_bg`) over its own
     * camera preview during an active-liveness capture and takes that image's
     * alpha from here. It defaults to **`1`** — fully opaque — so the customer
     */
    activeLivenessOpacity?: number;
    invertedAnimation?: boolean;
    activeLivenessAutoNextEnabled?: boolean;
}
export declare enum FaceRecognitionStatus {
    SUCCESS = "success",
    FAILURE = "failure",
    PHOTO_TAKEN = "photoTaken",
    SELFIE_TAKEN = "selfieTaken",
    ERROR = "error"
}
export interface FaceRecognitionError {
    code: string;
    message: string;
    details?: Record<string, any>;
}
export interface FaceIDResult {
    verified: boolean;
    matchScore: number;
    description: string;
    transactionID?: string;
    userID?: string;
    method?: string;
    header?: string;
    listNames?: string;
    listIds?: string;
    registrationTransactionID?: string;
    referencePhotoBase64?: string;
    error?: FaceRecognitionError;
    metadata?: Record<string, any>;
    rawServerResponse?: Record<string, any>;
}
export interface LivenessResult {
    assessmentValue: number;
    assessmentDescription: string;
    probability: number;
    quality: number;
    livenessScore: number;
    transactionID?: string;
    assessment?: string;
    error?: FaceRecognitionError;
}
export interface ActiveLivenessResult {
    transactionID?: string;
    gestureResult: Record<string, boolean>;
    error?: FaceRecognitionError;
}
export interface FaceIDMessage {
    success: boolean;
    message?: string;
    errorCode?: string;
    isFailed?: boolean;
    data?: Record<string, any>;
    faceIDResult?: FaceIDResult;
    livenessResult?: LivenessResult;
    activeLivenessResult?: ActiveLivenessResult;
}
export interface FaceRecognitionResult {
    status: FaceRecognitionStatus;
    faceIDMessage?: FaceIDMessage;
    error?: FaceRecognitionError;
    base64Image?: string;
}
export interface DemographicsResult {
    /** Estimated age in years. */
    estimatedAge: number;
    /** Estimated gender (e.g. 'male' | 'female'). */
    estimatedGender: string;
}
export declare enum LivenessPermissionStatus {
    GRANTED = "granted",
    DENIED = "denied",
    PERMANENTLY_DENIED = "permanentlyDenied",
    UNKNOWN = "unknown"
}
export interface FaceRecognitionPermissionStatus {
    camera: LivenessPermissionStatus;
    readPhoneState: LivenessPermissionStatus;
    internet: LivenessPermissionStatus;
    recordAudio?: LivenessPermissionStatus;
    bluetoothConnect?: LivenessPermissionStatus;
}
export interface CustomerList {
    id?: number;
    name?: string;
    listRole?: string;
    description?: string;
    creationDate?: string;
}
export interface ListResponseData {
    id?: number;
    customerList?: CustomerList;
    userId?: number;
}
export interface AddUserToListResult {
    success: boolean;
    data?: ListResponseData;
    error?: FaceRecognitionError;
}
export interface DeleteUserFromListResult {
    success: boolean;
    message?: string;
    userID?: string;
    transactionID?: string;
    listName?: string;
    matchScore?: number;
    registrationTransactionID?: string;
    error?: FaceRecognitionError;
}
export interface FontConfig {
    name: string;
    size: number;
}
export interface TextStyle {
    font?: FontConfig;
    textColor?: string;
    textAlignment?: 'left' | 'right' | 'center' | 'justified' | 'natural';
    lineBreakMode?: 'byWordWrapping' | 'byTruncatingTail' | 'byTruncatingHead' | 'byClipping';
    numberOfLines?: number;
    leading?: number;
    trailing?: number;
}
export interface ProgressBarStyle {
    backgroundColor?: string;
    progressColor?: string;
    completionColor?: string;
    textStyle?: TextStyle;
    cornerRadius?: number;
}
export interface UIColors {
    titleColor?: string;
    titleBG?: string;
    backgroundColor?: string;
    buttonColor?: string;
    buttonTextColor?: string;
    buttonSuccessColor?: string;
    buttonSuccessTextColor?: string;
    buttonErrorColor?: string;
    buttonErrorTextColor?: string;
    buttonBackColor?: string;
    footerTextColor?: string;
    checkmarkTintColor?: string;
    progressBackgroundColor?: string;
    gestureTextBackgroundColor?: string;
}
export interface UIFonts {
    titleFont?: FontConfig;
    buttonFont?: FontConfig;
    footerFont?: FontConfig;
    gestureFont?: FontConfig;
}
export interface UIDimensions {
    buttonHeight?: number;
    buttonMarginLeft?: number;
    buttonMarginRight?: number;
    buttonMarginBottom?: number;
    buttonCornerRadius?: number;
    gestureFontSize?: number;
    marginHorizontal?: number;
}
export interface UIConfigs {
    cameraPosition?: 'front' | 'back';
    autoTake?: boolean;
    errorDelay?: number;
    successDelay?: number;
    requestTimeout?: number;
    maskDetection?: boolean;
    maskConfidence?: number;
    invertedAnimation?: boolean;
    backButtonEnabled?: boolean;
    multipleFacesRejected?: boolean;
    bundle?: string;
    tableName?: string;
    progressBarStyle?: ProgressBarStyle;
}
export interface LocalizationStrings {
    udentifyface_header_text?: string;
    udentifyface_footer_button_text_default?: string;
    udentifyface_footer_button_text_progressing?: string;
    udentifyface_footer_button_text_result?: string;
    udentifyface_message_face_too_big?: string;
    udentifyface_message_face_too_small?: string;
    udentifyface_message_face_not_found?: string;
    udentifyface_message_too_many_faces?: string;
    udentifyface_message_face_angled?: string;
    udentifyface_message_head_angled?: string;
    udentifyface_message_face_off_center?: string;
    udentifyface_message_eyes_closed?: string;
    udentifyface_message_mask_detected?: string;
    udentifyface_gesture_text_move_head_to_left?: string;
    udentifyface_gesture_text_move_head_to_right?: string;
    udentifyface_gesture_text_move_head_to_up?: string;
    udentifyface_gesture_text_move_head_to_down?: string;
    udentifyface_gesture_text_blink_once?: string;
    udentifyface_gesture_text_blink_twice?: string;
    udentifyface_gesture_text_blink_thrice?: string;
    udentifyface_gesture_text_smile?: string;
    udentifyface_active_liveness_footer_button_text_recording?: string;
    udentifyface_active_liveness_footer_button_text_processing?: string;
    udentifyface_active_liveness_footer_button_text_default?: string;
    udentifyface_active_liveness_footer_button_text_result?: string;
    udentifyface_active_liveness_footer_label_text_processing?: string;
}
export interface UISettings {
    colors?: UIColors;
    fonts?: UIFonts;
    dimensions?: UIDimensions;
    configs?: UIConfigs;
    localization?: {
        languageCode?: string;
        customStrings?: LocalizationStrings;
    };
}
export type OnResultCallback = (result: FaceRecognitionResult) => void;
export type OnFailureCallback = (error: FaceRecognitionError) => void;
export type OnPhotoTakenCallback = () => void;
export type OnSelfieTakenCallback = (base64Image: string) => void;
export type OnVideoTakenCallback = () => void;
export type OnActiveLivenessResultCallback = (result: FaceRecognitionResult) => void;
export type OnActiveLivenessFailureCallback = (error: FaceRecognitionError) => void;
//# sourceMappingURL=LivenessModels.d.ts.map