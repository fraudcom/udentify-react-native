/**
 * liveness-rn-library
 * React Native TurboModule for Face Recognition & Liveness Detection
 */
export * from './LivenessModels';
export * from './NativeLivenessModule';
export { default as LivenessModule } from './LivenessModule';
export type { FaceRepeatConfig } from './FaceRepeat';
export { setRepeatConfig } from './FaceRepeat';
//# sourceMappingURL=index.d.ts.map