/**
 * Liveness Module
 * Main interface for Face Recognition & Liveness Detection functionality
 */
import type { FaceRecognizerCredentials, FaceRecognitionResult, FaceRecognitionPermissionStatus, AddUserToListResult, DeleteUserFromListResult, UISettings, LocalizationStrings, DemographicsResult, OnResultCallback, OnFailureCallback, OnPhotoTakenCallback, OnSelfieTakenCallback, OnActiveLivenessResultCallback, OnActiveLivenessFailureCallback } from './LivenessModels';
declare class LivenessModule {
    private eventEmitter;
    private callbacks;
    constructor();
    private setupEventListeners;
    checkPermissions(): Promise<FaceRecognitionPermissionStatus>;
    requestPermissions(): Promise<FaceRecognitionPermissionStatus>;
    startFaceRecognitionRegistration(credentials: FaceRecognizerCredentials): Promise<FaceRecognitionResult>;
    startFaceRecognitionAuthentication(credentials: FaceRecognizerCredentials): Promise<FaceRecognitionResult>;
    startActiveLiveness(credentials: FaceRecognizerCredentials, isAuthentication?: boolean): Promise<FaceRecognitionResult>;
    startHybridLiveness(credentials: FaceRecognizerCredentials, isAuthentication?: boolean): Promise<FaceRecognitionResult>;
    startSelfieCapture(credentials: FaceRecognizerCredentials): Promise<FaceRecognitionResult>;
    performFaceRecognitionWithSelfie(credentials: FaceRecognizerCredentials, base64Image: string, isAuthentication?: boolean): Promise<FaceRecognitionResult>;
    registerUserWithPhoto(credentials: FaceRecognizerCredentials, base64Image: string): Promise<FaceRecognitionResult>;
    authenticateUserWithPhoto(credentials: FaceRecognizerCredentials, base64Image: string): Promise<FaceRecognitionResult>;
    cancelFaceRecognition(): Promise<void>;
    isFaceRecognitionInProgress(): Promise<boolean>;
    estimateDemographics(serverURL: string, transactionID: string, imageBase64: string): Promise<DemographicsResult>;
    addUserToList(serverURL: string, transactionId: string, status: string, metadata?: Record<string, any>): Promise<AddUserToListResult>;
    startFaceRecognitionIdentification(serverURL: string, transactionId: string, listName: string, logLevel?: string): Promise<FaceRecognitionResult>;
    deleteUserFromList(serverURL: string, transactionId: string, listName: string, photoBase64: string): Promise<DeleteUserFromListResult>;
    configureUISettings(settings: UISettings): Promise<boolean>;
    setLocalization(languageCode: string, customStrings?: LocalizationStrings): Promise<void>;
    applyUIConfiguration(settings: UISettings): Promise<boolean>;
    setOnResultCallback(callback: OnResultCallback): void;
    setOnFailureCallback(callback: OnFailureCallback): void;
    setOnPhotoTakenCallback(callback: OnPhotoTakenCallback): void;
    setOnSelfieTakenCallback(callback: OnSelfieTakenCallback): void;
    setOnActiveLivenessResultCallback(callback: OnActiveLivenessResultCallback): void;
    setOnActiveLivenessFailureCallback(callback: OnActiveLivenessFailureCallback): void;
    setOnVideoTakenCallback(callback: () => void): void;
    removeAllListeners(): void;
}
declare const _default: LivenessModule;
export default _default;
//# sourceMappingURL=LivenessModule.d.ts.map