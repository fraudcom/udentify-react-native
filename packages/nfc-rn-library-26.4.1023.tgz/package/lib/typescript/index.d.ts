import { EmitterSubscription } from 'react-native';
export interface NFCCredentials {
    documentNumber: string;
    dateOfBirth: string;
    expiryDate: string;
    serverURL: string;
    transactionID: string;
    requestTimeout?: number;
    isActiveAuthenticationEnabled?: boolean;
    isPassiveAuthenticationEnabled?: boolean;
    enableAutoTriggering?: boolean;
    logLevel?: 'warning' | 'info' | 'debug' | 'error';
}
/**
 * NFC Passport/ID Response interface based on Udentify SDK
 */
export interface NFCPassportResponse {
    success: boolean;
    transactionID: string;
    timestamp: number;
    firstName?: string;
    lastName?: string;
    documentNumber?: string;
    nationality?: string;
    dateOfBirth?: string;
    expiryDate?: string;
    gender?: string;
    personalNumber?: string;
    placeOfBirth?: string;
    issuingAuthority?: string;
    documentType?: string;
    documentCode?: string;
    dateOfIssue?: string;
    address?: string;
    phoneNumber?: string;
    email?: string;
    accessControlProtocol?: 'none' | 'bac' | 'pace';
    passedPA?: 'disabled' | 'true' | 'false' | 'notSupported';
    passedAA?: 'disabled' | 'true' | 'false' | 'notSupported';
    passedCA?: 'disabled' | 'true' | 'false' | 'notSupported';
    faceImage?: string;
    signatureImage?: string;
    error?: string;
    message?: string;
}
/**
 * NFC Status Response interface
 */
export interface NFCStatusResponse {
    isAvailable: boolean;
    isEnabled: boolean;
    message?: string;
}
/**
 * NFC Location Response interface
 */
export interface NFCLocationResponse {
    success: boolean;
    location: NFCLocation;
    message?: string;
}
/**
 * NFC Location enum based on Udentify SDK
 */
export declare enum NFCLocation {
    unknown = 0,
    frontTop = 1,
    frontCenter = 2,
    frontBottom = 3,
    rearTop = 4,
    rearCenter = 5,
    rearBottom = 6
}
/**
 * Check if the device has NFC hardware.
 *
 * On Android this is the SDK's own hardware check: `false` only on a phone with no
 * chip, and still `true` when the user has NFC switched off in the system settings.
 */
export declare function isNFCAvailable(): Promise<boolean>;
/**
 * Check if NFC is enabled on the device
 */
export declare function isNFCEnabled(): Promise<boolean>;
/**
 * Start NFC passport/ID reading with MRZ credentials
 */
export declare function startNFCReading(credentials: NFCCredentials): Promise<NFCPassportResponse>;
/**
 * Cancel ongoing NFC reading session
 */
export declare function cancelNFCReading(): Promise<boolean>;
/**
 * Get NFC antenna location for current device
 */
export declare function getNFCLocation(serverURL: string): Promise<NFCLocationResponse>;
/**
 * NFC Progress Event payload — emitted from native side during passport reading.
 */
export interface NFCProgressEvent {
    progress: number;
    timestamp: number;
}
/**
 * Subscribe to NFC reading progress events. Returns an EmitterSubscription;
 * call `.remove()` (e.g. in a useEffect cleanup) to unsubscribe.
 */
export declare function addNFCProgressListener(callback: (event: NFCProgressEvent) => void): EmitterSubscription;
/**
 * Get NFC status (availability and enabled state)
 */
export declare function getNFCStatus(): Promise<NFCStatusResponse>;
/** Credentials an in-call NFC re-capture runs with. */
export interface NFCRepeatConfig {
    serverURL: string;
    transactionID: string;
    /**
     * Whether to run passive authentication on the chip's signed data objects.
     * Omitted, the native SDK's own default applies.
     */
    passiveAuthentication?: boolean;
    /**
     * An MRZ the app already has, for an NFC repeat that comes without an OCR repeat.
     * Optional: without it the repeat needs an OCR repeat in the same call.
     * Personal data kept until `setRepeatConfig(null)`: clear it when the call ends.
     */
    mrz?: NFCRepeatMRZ;
}
/** The three chip access fields. */
export interface NFCRepeatMRZ {
    /** As printed in the MRZ, upper case, no spaces. */
    documentNumber: string;
    /** `YYMMDD`, exactly 6 digits. */
    dateOfBirth: string;
    /** `YYMMDD`, exactly 6 digits. */
    expiryDate: string;
    /**
     * `true` (the default): the MRZ of an OCR repeat in the call wins and this one is
     * the fallback. `false`: this one is always used.
     */
    preferCapturedMRZ?: boolean;
}
/**
 * Opts this app into in-call NFC re-captures. **Android only, off by default.**
 * Pass `null` to opt back out.
 * Call it before starting the video call. The BAC key comes from an OCR repeat in
 * the same call or from `mrz`; with neither the repeat is refused.
 */
export declare function setRepeatConfig(config: NFCRepeatConfig | null): Promise<boolean>;
//# sourceMappingURL=index.d.ts.map