export * from './VideoCallModels';
export { NativeVideoCallModule } from './NativeVideoCallModule';
import type { VideoCallCredentials, VideoCallResult, VideoCallStatus, VideoCallConfig, VideoCallPermissionStatus, VideoCallCallbacks } from './VideoCallModels';
/**
 * VideoCall - Main class for video call functionality
 * Equivalent to Flutter's VideoCallFlutter class
 *
 * This class provides a simple interface for video calling using Udentify's SDK.
 * All methods are static and mirror the Flutter implementation.
 */
export declare class VideoCall {
    /**
     * Check current permissions status
     * @returns Promise<VideoCallPermissionStatus> Current permission status
     */
    static checkPermissions(): Promise<VideoCallPermissionStatus>;
    /**
     * Request necessary permissions for video call functionality
     * @returns Promise<string> Result of permission request ('granted' | 'denied' | 'error')
     */
    static requestPermissions(): Promise<string>;
    /**
     * Start video call with given credentials
     * @param credentials VideoCallCredentials object with server details and user info
     * @returns Promise<VideoCallResult> Result of the start operation
     */
    static startVideoCall(credentials: VideoCallCredentials): Promise<VideoCallResult>;
    /**
     * End ongoing video call
     * @returns Promise<VideoCallResult> Result of the end operation
     */
    static endVideoCall(): Promise<VideoCallResult>;
    /**
     * Get current video call status
     * @returns Promise<VideoCallStatus> Current status of the video call
     */
    static getVideoCallStatus(): Promise<VideoCallStatus>;
    /**
     * Configure UI settings for Video Call camera
     * This method should be called before starting video call to apply custom UI settings
     * @param uiConfig VideoCallConfig object with UI customization options
     * @returns Promise<boolean>
     */
    static configureUISettings(uiConfig: VideoCallConfig): Promise<boolean>;
    /**
     * Set video call UI configuration
     * @param config VideoCallConfig object with UI customization options
     * @returns Promise<void>
     */
    static setVideoCallConfig(config: VideoCallConfig): Promise<void>;
    /**
     * Toggle camera on/off
     * @returns Promise<boolean> Current camera state after toggle (true = on, false = off)
     */
    static toggleCamera(): Promise<boolean>;
    /**
     * Switch between front and back camera
     * @returns Promise<boolean> Success state of the camera switch operation
     */
    static switchCamera(): Promise<boolean>;
    /**
     * Toggle microphone on/off
     * @returns Promise<boolean> Current microphone state after toggle (true = on, false = off)
     */
    static toggleMicrophone(): Promise<boolean>;
    /**
     * Dismiss video call UI
     * @returns Promise<void>
     */
    static dismissVideoCall(): Promise<void>;
    /**
     * Cancel an in-progress video call transaction on the server.
     * Requires an active/presented video call session.
     * @returns Promise<VideoCallResult> Result of the cancel operation
     */
    static cancelVideoCall(): Promise<VideoCallResult>;
    /**
     * Set callbacks for video call events
     * @param callbacks VideoCallCallbacks object with event handlers
     */
    static setCallbacks(callbacks: VideoCallCallbacks): void;
    /**
     * Clear all event listeners
     */
    static clearEventListeners(): void;
    /**
     * Set status change callback
     * @param callback Function to handle status changes
     */
    static setOnStatusChanged(callback: (status: VideoCallStatus) => void): void;
    /**
     * Set error callback
     * @param callback Function to handle errors
     */
    static setOnError(callback: (error: any) => void): void;
}
export default VideoCall;
//# sourceMappingURL=index.d.ts.map