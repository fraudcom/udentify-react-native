/**
 * Video Call Credentials for authentication and connection
 */
export interface VideoCallCredentials {
    serverURL: string;
    wssURL: string;
    userID: string;
    transactionID: string;
    clientName: string;
    idleTimeout?: string;
}
/**
 * Video Call Status enumeration
 */
export declare enum VideoCallStatus {
    IDLE = "idle",
    CONNECTING = "connecting",
    CONNECTED = "connected",
    DISCONNECTED = "disconnected",
    FAILED = "failed",
    COMPLETED = "completed"
}
/**
 * Video Call Error Types
 */
export declare enum VideoCallErrorType {
    UNKNOWN = "ERR_UNKNOWN",
    CREDENTIALS_MISSING = "ERR_CREDENTIALS_MISSING",
    SERVER_TIMEOUT = "ERR_SERVER_TIMEOUT_EXCEPTION",
    TRANSACTION_NOT_FOUND = "ERR_TRANSACTION_NOT_FOUND",
    TRANSACTION_FAILED = "ERR_TRANSACTION_FAILED",
    TRANSACTION_EXPIRED = "ERR_TRANSACTION_EXPIRED",
    TRANSACTION_ALREADY_COMPLETED = "ERR_TRANSACTION_ALREADY_COMPLETED",
    SDK_NOT_AVAILABLE = "ERR_SDK_NOT_AVAILABLE"
}
/**
 * Video Call Error
 */
export interface VideoCallError {
    type: VideoCallErrorType;
    message: string;
    details?: string;
}
/**
 * Video Call Result from operations
 */
export interface VideoCallResult {
    success: boolean;
    status?: VideoCallStatus;
    transactionID?: string;
    error?: VideoCallError;
    metadata?: Record<string, any>;
}
/**
 * Video Call UI Configuration
 */
export interface VideoCallConfig {
    backgroundColor?: string;
    textColor?: string;
    pipViewBorderColor?: string;
    notificationLabelDefault?: string;
    notificationLabelCountdown?: string;
    notificationLabelTokenFetch?: string;
    tableName?: string;
    requestTimeout?: number;
}
/**
 * Permission Status for Video Call
 */
export interface VideoCallPermissionStatus {
    hasCameraPermission: boolean;
    hasPhoneStatePermission: boolean;
    hasInternetPermission: boolean;
    hasRecordAudioPermission: boolean;
}
/**
 * Video Call Event Callbacks
 */
export interface VideoCallCallbacks {
    onStatusChanged?: (status: VideoCallStatus) => void;
    onError?: (error: VideoCallError) => void;
    onUserStateChanged?: (state: string) => void;
    onParticipantStateChanged?: (participantType: string, state: string) => void;
    onVideoCallEnded?: (success: boolean) => void;
    onVideoCallDismissed?: () => void;
}
/**
 * Helper functions for type conversion
 */
export declare class VideoCallUtils {
    /**
     * Convert string to VideoCallStatus enum
     */
    static stringToStatus(value: string): VideoCallStatus;
    /**
     * Convert string to VideoCallErrorType enum
     */
    static stringToErrorType(value: string): VideoCallErrorType;
    /**
     * Check if all permissions are granted
     */
    static areAllPermissionsGranted(permissions: VideoCallPermissionStatus): boolean;
    /**
     * Create a VideoCallError from native response
     */
    static createErrorFromMap(errorMap: any): VideoCallError;
    /**
     * Create a VideoCallResult from native response
     */
    static createResultFromMap(resultMap: any): VideoCallResult;
    /**
     * Convert VideoCallCredentials to map for native bridge
     */
    static credentialsToMap(credentials: VideoCallCredentials): Record<string, any>;
    /**
     * Convert VideoCallConfig to map for native bridge
     */
    static configToMap(config: VideoCallConfig): Record<string, any>;
    /**
     * Create VideoCallPermissionStatus from native response
     */
    static createPermissionsFromMap(permissionsMap: any): VideoCallPermissionStatus;
}
//# sourceMappingURL=VideoCallModels.d.ts.map