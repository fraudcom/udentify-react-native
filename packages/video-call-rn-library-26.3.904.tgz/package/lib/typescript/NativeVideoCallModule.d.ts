import type { VideoCallCredentials, VideoCallResult, VideoCallStatus, VideoCallConfig, VideoCallPermissionStatus, VideoCallCallbacks } from './VideoCallModels';
export type { VideoCallCredentials as VideoCallCredentials_TurboModule, VideoCallResult as VideoCallResult_TurboModule, VideoCallConfig as VideoCallConfig_TurboModule, } from './NativeVideoCallModuleSpec';
/**
 * Native Video Call Module - React Native bridge to native implementations
 * Provides the same functionality as Flutter VideoCallFlutter class
 */
export declare class NativeVideoCallModule {
    private static eventEmitter;
    private static callbacks;
    /**
     * Initialize event emitter safely
     */
    private static getEventEmitter;
    /**
     * Initialize event listeners for callbacks
     */
    private static initializeEventListeners;
    /**
     * Set callbacks for video call events
     */
    static setCallbacks(callbacks: VideoCallCallbacks): void;
    /**
     * Clear all event listeners
     */
    static clearEventListeners(): void;
    /**
     * Check current permissions status
     */
    static checkPermissions(): Promise<VideoCallPermissionStatus>;
    /**
     * Request necessary permissions for video call functionality
     */
    static requestPermissions(): Promise<string>;
    /**
     * Start video call with given credentials
     */
    static startVideoCall(credentials: VideoCallCredentials): Promise<VideoCallResult>;
    /**
     * End ongoing video call
     */
    static endVideoCall(): Promise<VideoCallResult>;
    /**
     * Get current video call status
     */
    static getVideoCallStatus(): Promise<VideoCallStatus>;
    /**
     * Configure UI settings for Video Call camera
     * This method should be called before starting video call to apply custom UI settings
     */
    static configureUISettings(uiConfig: VideoCallConfig): Promise<boolean>;
    /**
     * Set video call UI configuration
     */
    static setVideoCallConfig(config: VideoCallConfig): Promise<void>;
    /**
     * Toggle camera on/off
     */
    static toggleCamera(): Promise<boolean>;
    /**
     * Switch between front and back camera
     */
    static switchCamera(): Promise<boolean>;
    /**
     * Toggle microphone on/off
     */
    static toggleMicrophone(): Promise<boolean>;
    /**
     * Dismiss video call UI
     */
    static dismissVideoCall(): Promise<void>;
    /**
     * Cancel an in-progress video call transaction on the server.
     * Requires an active/presented video call session.
     */
    static cancelVideoCall(): Promise<VideoCallResult>;
}
export default NativeVideoCallModule;
//# sourceMappingURL=NativeVideoCallModule.d.ts.map