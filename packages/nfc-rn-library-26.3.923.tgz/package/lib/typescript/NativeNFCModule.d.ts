import type { TurboModule } from 'react-native';
export interface NFCCredentials {
    documentNumber: string;
    dateOfBirth: string;
    expiryDate: string;
    serverURL: string;
    transactionID: string;
    requestTimeout?: number;
    isActiveAuthenticationEnabled?: boolean;
    isPassiveAuthenticationEnabled?: boolean;
    enableAutoTriggering?: boolean;
    logLevel?: string;
}
export interface Spec extends TurboModule {
    isNFCAvailable(): Promise<boolean>;
    isNFCEnabled(): Promise<boolean>;
    startNFCReading(credentials: NFCCredentials): Promise<object>;
    cancelNFCReading(): Promise<boolean>;
    setRepeatConfig(config: Object | null): Promise<boolean>;
    getNFCLocation(serverURL: string): Promise<object>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeNFCModule.d.ts.map