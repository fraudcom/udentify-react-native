import { EmitterSubscription } from 'react-native';
export interface NFCCredentials {
    documentNumber: string;
    dateOfBirth: string;
    expiryDate: string;
    serverURL: string;
    transactionID: string;
    requestTimeout?: number;
    isActiveAuthenticationEnabled?: boolean;
    isPassiveAuthenticationEnabled?: boolean;
    enableAutoTriggering?: boolean;
    logLevel?: 'warning' | 'info' | 'debug' | 'error';
}
/**
 * NFC Passport/ID Response interface based on Udentify SDK
 */
export interface NFCPassportResponse {
    success: boolean;
    transactionID: string;
    timestamp: number;
    firstName?: string;
    lastName?: string;
    documentNumber?: string;
    nationality?: string;
    dateOfBirth?: string;
    expiryDate?: string;
    gender?: string;
    personalNumber?: string;
    placeOfBirth?: string;
    issuingAuthority?: string;
    passedPA?: 'disabled' | 'true' | 'false' | 'notSupported';
    passedAA?: 'disabled' | 'true' | 'false' | 'notSupported';
    faceImage?: string;
    signatureImage?: string;
    error?: string;
    message?: string;
}
/**
 * NFC Status Response interface
 */
export interface NFCStatusResponse {
    isAvailable: boolean;
    isEnabled: boolean;
    message?: string;
}
/**
 * NFC Location Response interface
 */
export interface NFCLocationResponse {
    success: boolean;
    location: NFCLocation;
    message?: string;
}
/**
 * NFC Location enum based on Udentify SDK
 */
export declare enum NFCLocation {
    unknown = 0,
    frontTop = 1,
    frontCenter = 2,
    frontBottom = 3,
    rearTop = 4,
    rearCenter = 5,
    rearBottom = 6
}
/**
 * Check if NFC is available on the device
 */
export declare function isNFCAvailable(): Promise<boolean>;
/**
 * Check if NFC is enabled on the device
 */
export declare function isNFCEnabled(): Promise<boolean>;
/**
 * Start NFC passport/ID reading with MRZ credentials
 */
export declare function startNFCReading(credentials: NFCCredentials): Promise<NFCPassportResponse>;
/**
 * Cancel ongoing NFC reading session
 */
export declare function cancelNFCReading(): Promise<boolean>;
/**
 * Get NFC antenna location for current device
 */
export declare function getNFCLocation(serverURL: string): Promise<NFCLocationResponse>;
/**
 * NFC Progress Event payload — emitted from native side during passport reading.
 */
export interface NFCProgressEvent {
    progress: number;
    timestamp: number;
}
/**
 * Subscribe to NFC reading progress events. Returns an EmitterSubscription;
 * call `.remove()` (e.g. in a useEffect cleanup) to unsubscribe.
 */
export declare function addNFCProgressListener(callback: (event: NFCProgressEvent) => void): EmitterSubscription;
/**
 * Get NFC status (availability and enabled state)
 */
export declare function getNFCStatus(): Promise<NFCStatusResponse>;
/** Credentials an in-call NFC re-capture runs with. */
export interface NFCRepeatConfig {
    serverURL: string;
    transactionID: string;
    /**
     * Whether to run passive authentication on the chip's signed data objects.
     * Omitted, the native SDK's own default applies.
     */
    passiveAuthentication?: boolean;
}
/**
 * Opts this app into in-call NFC re-captures. **Android only, off by default.**
 * Pass `null` to opt back out.
 * Call it before starting the video call. An NFC repeat needs a completed OCR
 * repeat in the same call for its BAC key material, so run OCR first.
 */
export declare function setRepeatConfig(config: NFCRepeatConfig | null): Promise<boolean>;
//# sourceMappingURL=index.d.ts.map